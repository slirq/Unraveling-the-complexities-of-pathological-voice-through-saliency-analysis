# 1D-CNN based End2End Segmentation Pipeline in TensorFlow 2.0 and KERAS
This is a sample pipeline for implementing 1D-CNN based segmentation networks using TF2.0 and KERAS. Details regarding the pipeline is provided in the following repository: https://github.com/Sakib1263/NABNet  
The pipeline can be easily modified and used for any other dataset prepared similarly. Only the data preprocessing section needs to be changed in that case.  
